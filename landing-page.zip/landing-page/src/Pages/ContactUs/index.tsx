import {FC} from "react";
import Contact from "../../components/Contact"

const ContactUs: FC = () => {
  return (
    <Contact/>
  );
}

export default ContactUs;