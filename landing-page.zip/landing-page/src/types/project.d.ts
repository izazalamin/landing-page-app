type Project = {
    name: string;
    roles: string[];
    link: string;
  }