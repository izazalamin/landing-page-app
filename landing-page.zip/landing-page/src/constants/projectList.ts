
const DUMMY_PROJECTS: Project[] = [
    {
      name: "Decodable.co",
      roles: ["Brand Design", "Webflow Development", "Web Design"],
      link: "https://decodable.co"
    },
    {
      name: "Gofirefly.io",
      roles: ["Brand Design", "Webflow Development", "Web Design"],
      link: "https://gofirefly.io"
    },
    {
      name: "Blinkops.com",
      roles: ["Brand Design", "Webflow Development", "Web Design"],
      link: "https://Blinkops.com"
    },
    {
      name: "Withkanvas.com",
      roles: ["Brand Design", "Webflow Development", "Web Design"],
      link: "https://Withkanvas.com"
    },
  ]
  
  export { DUMMY_PROJECTS };